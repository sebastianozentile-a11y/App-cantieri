package com.example.cantieri

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

data class Cantiere(var nome:String, var cliente:String, var telefono:String, var indirizzo:String, var note:String)

class MainActivity: AppCompatActivity() {
    private val cantieri = mutableListOf<Cantiere>()
    private lateinit var list: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        home()
    }

    private fun home() {
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(24,28,24,20) }
        val title=TextView(this).apply { text="I MIEI CANTIERI"; textSize=28f; setTextColor(Color.rgb(20,20,20)); setPadding(0,0,0,24) }
        root.addView(title)
        val add=Button(this).apply { text="➕  NUOVO CANTIERE"; setOnClickListener { nuovoCantiere() } }
        root.addView(add, LinearLayout.LayoutParams(-1,60))
        list=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(0,20,0,0) }
        root.addView(list, LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root); refresh()
    }

    private fun refresh() {
        list.removeAllViews()
        if(cantieri.isEmpty()) list.addView(TextView(this).apply { text="Nessun cantiere ancora.\nPremi “Nuovo cantiere” per iniziare."; textSize=18f; setPadding(8,30,8,8) })
        cantieri.forEachIndexed { i,c ->
            val card=Button(this).apply { text="🏗️  ${c.nome}\n${c.cliente}"; textSize=17f; gravity=Gravity.START or Gravity.CENTER_VERTICAL
                setOnClickListener { profilo(i) } }
            list.addView(card, LinearLayout.LayoutParams(-1,90).apply { bottomMargin=14 })
        }
    }

    private fun nuovoCantiere() {
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(30,10,30,10) }
        val fields=listOf("Nome cantiere","Nome cliente","Numero di telefono","Indirizzo","Note").map { EditText(this).apply { hint=it } }
        fields.forEach { box.addView(it) }
        AlertDialog.Builder(this).setTitle("Nuovo cantiere").setView(box).setPositiveButton("Salva"){_,_->
            cantieri.add(Cantiere(*fields.map { it.text.toString() }.toTypedArray())); refresh()
        }.setNegativeButton("Annulla",null).show()
    }

    private fun profilo(i:Int) {
        val c=cantieri[i]
        val root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(24,28,24,20) }
        root.addView(TextView(this).apply { text="🏗️\n${c.nome}"; textSize=28f; setPadding(0,0,0,20) })
        root.addView(TextView(this).apply { text="👤 ${c.cliente}\n\n📞 ${c.telefono}\n\n📍 ${c.indirizzo}\n\n📝 ${c.note}"; textSize=18f; setPadding(0,0,0,20) })
        val call=Button(this).apply { text="📞  CHIAMA"; setOnClickListener { startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${c.telefono}"))) } }
        root.addView(call)
        val nav=Button(this).apply { text="📍  NAVIGA"; setOnClickListener { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q="+Uri.encode(c.indirizzo)))) } }
        root.addView(nav)
        listOf("📷  Bolle e materiale","📋  Materiale utilizzato","📦  Materiale in magazzino","📄  Riepilogo PDF","📝  Note").forEach { label ->
            root.addView(Button(this).apply { text=label; setOnClickListener { Toast.makeText(this@MainActivity,"Funzione prevista nella prossima versione",Toast.LENGTH_SHORT).show() } })
        }
        root.addView(Button(this).apply { text="✏️  MODIFICA PROFILO"; setOnClickListener { nuovoCantiere() } })
        root.addView(Button(this).apply { text="←  TORNA AI CANTIERI"; setOnClickListener { home() } })
        setContentView(root)
    }
}
